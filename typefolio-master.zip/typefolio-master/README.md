typefolio
=========

## Overview

Typefolio is a template for agencies/designers/photographers/etc. 


## Preview

[http://preview.typebig.com/typefolio-html/](http://preview.typebig.com/typefolio-html/)

![Screenshot](http://preview.typebig.com/github-preview-images/typefolio_github_preview.png)



## Features
* Valid W3C HTML5
* Fully responsive
* Custom-built Responsive CSS Grid System
* Custom-built JS menu & sticky sidebar
* Lightweight



## License Information

* Feel free to use it in a personal/commercial project. 
* Please do not resell in template/theme markets!
* I've purchased the images from various sources (mainly Shutterstock), and I don't have extended licenses for most of them. In other words, **you can't use the placeholder images as-is**.



## Author

Feel free to e-mail me at [subwaymatch@gmail.com](mailto:subwaymatch@gmail.com) for any questions. 
